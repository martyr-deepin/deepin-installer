#!/bin/sh

grub_modinfo_target_cpu=x86_64
grub_modinfo_platform=efi
